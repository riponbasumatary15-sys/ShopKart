// ─── FIREBASE HELPERS ─────────────────────────────────────────────────────
import { auth, db, storage } from "./firebase";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  updateProfile
} from "firebase/auth";
import {
  doc, setDoc, getDoc, collection,
  addDoc, updateDoc, deleteDoc,
  getDocs, query, where, orderBy, serverTimestamp
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

// ── AUTH ──────────────────────────────────────────────────────────────────

// Register new buyer
export async function registerBuyer(name, email, password) {
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(cred.user, { displayName: name });
  const uid = cred.user.uid;
  const custId = "CUST" + uid.slice(0,6).toUpperCase();
  await setDoc(doc(db, "users", uid), {
    name, email, role: "buyer",
    customerId: custId,
    createdAt: serverTimestamp()
  });
  return { id: uid, name, email, customerId: custId, role: "buyer" };
}

// Register new seller
export async function registerSeller(name, email, password, storeName) {
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  const uid = cred.user.uid;
  const sellerId = "SELL" + uid.slice(0,4).toUpperCase();
  await setDoc(doc(db, "sellers", uid), {
    name, email, storeName, sellerId,
    rating: 0, totalSales: 0,
    createdAt: serverTimestamp()
  });
  return { id: uid, name, email, storeName, sellerId, role: "seller" };
}

// Login buyer
export async function loginBuyer(email, password) {
  const cred = await signInWithEmailAndPassword(auth, email, password);
  const snap = await getDoc(doc(db, "users", cred.user.uid));
  if (!snap.exists()) throw new Error("User not found in database");
  return { id: cred.user.uid, ...snap.data() };
}

// Login seller
export async function loginSeller(email, password) {
  const cred = await signInWithEmailAndPassword(auth, email, password);
  const snap = await getDoc(doc(db, "sellers", cred.user.uid));
  if (!snap.exists()) throw new Error("Seller not found in database");
  return { id: cred.user.uid, ...snap.data() };
}

// Logout
export async function logoutUser() {
  await signOut(auth);
}

// ── PRODUCTS ──────────────────────────────────────────────────────────────

// Add product (with optional image upload to Firebase Storage)
export async function addProduct(sellerId, sellerName, form, imageFile) {
  let imgUrl = form.img || "👕";
  if (imageFile) {
    const storageRef = ref(storage, `products/${sellerId}/${Date.now()}_${imageFile.name}`);
    await uploadBytes(storageRef, imageFile);
    imgUrl = await getDownloadURL(storageRef);
  }
  const docRef = await addDoc(collection(db, "products"), {
    sellerId, sellerName,
    name: form.name,
    price: Number(form.price),
    mrp: Number(form.mrp),
    category: form.category,
    subcat: form.subcat || "all",
    description: form.description,
    stock: Number(form.stock),
    imgUrl,
    orders: 0,
    rating: 0,
    reviews: 0,
    createdAt: serverTimestamp()
  });
  return docRef.id;
}

// Get all products
export async function getAllProducts() {
  const snap = await getDocs(collection(db, "products"));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

// Get seller's products
export async function getSellerProducts(sellerId) {
  const q = query(collection(db, "products"), where("sellerId", "==", sellerId));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

// Update product
export async function updateProduct(productId, updates) {
  await updateDoc(doc(db, "products", productId), updates);
}

// Delete product
export async function deleteProduct(productId) {
  await deleteDoc(doc(db, "products", productId));
}

// ── ORDERS ────────────────────────────────────────────────────────────────

// Place order
export async function placeOrder(userId, items, total, deliveryInfo, paymentInfo) {
  const order = {
    userId,
    items: items.map(i => ({
      id: i.id, name: i.name, price: i.price,
      qty: i.qty, img: i.img || "👕"
    })),
    total,
    deliveryAddress: deliveryInfo,
    payment: paymentInfo,
    status: "Confirmed",
    tracking: [
      { status: "Order Confirmed", time: new Date().toISOString(), done: true },
      { status: "Processing",      time: "", done: false },
      { status: "Shipped",         time: "", done: false },
      { status: "Out for Delivery",time: "", done: false },
      { status: "Delivered",       time: "", done: false },
    ],
    createdAt: serverTimestamp()
  };
  const ref = await addDoc(collection(db, "orders"), order);
  return { id: ref.id, ...order };
}

// Get user orders
export async function getUserOrders(userId) {
  const q = query(
    collection(db, "orders"),
    where("userId", "==", userId),
    orderBy("createdAt", "desc")
  );
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

// Update order tracking (for seller/admin)
export async function updateOrderTracking(orderId, trackingSteps) {
  await updateDoc(doc(db, "orders", orderId), { tracking: trackingSteps });
}

// ── USER PROFILE ──────────────────────────────────────────────────────────

export async function updateUserProfile(userId, updates) {
  await updateDoc(doc(db, "users", userId), updates);
  if (auth.currentUser) await updateProfile(auth.currentUser, { displayName: updates.name });
}

export async function saveUserAddress(userId, addresses) {
  await updateDoc(doc(db, "users", userId), { addresses });
}
