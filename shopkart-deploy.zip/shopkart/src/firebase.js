// ─── FIREBASE CONFIG ───────────────────────────────────────────────────────
// 👇 Yahan apni Firebase keys daalo (firebase.google.com → Project Settings)
// Steps:
// 1. firebase.google.com → Console → New Project → "ShopKart"
// 2. Project Settings (gear icon) → General → Your Apps → Add Web App
// 3. Neeche wali values copy karo aur yahan paste karo

import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey:            "YOUR_API_KEY",           // 👈 Replace
  authDomain:        "YOUR_AUTH_DOMAIN",       // 👈 Replace
  projectId:         "YOUR_PROJECT_ID",        // 👈 Replace
  storageBucket:     "YOUR_STORAGE_BUCKET",    // 👈 Replace
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID", // 👈 Replace
  appId:             "YOUR_APP_ID"             // 👈 Replace
};

const app   = initializeApp(firebaseConfig);
export const auth    = getAuth(app);
export const db      = getFirestore(app);
export const storage = getStorage(app);
