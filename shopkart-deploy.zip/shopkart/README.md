# 🛍️ ShopKart — Deployment Guide

## Abhi jo files hain:
```
shopkart/
├── public/index.html
├── src/
│   ├── App.jsx          ← Main app (poora ShopKart)
│   ├── index.js         ← Entry point
│   ├── firebase.js      ← Firebase config (keys daalo)
│   └── firebaseHelpers.js ← Auth, DB, Storage functions
├── package.json
└── vercel.json
```

---

## STEP 1: GitHub pe upload karo

1. github.com → Sign up (free)
2. New Repository → Name: `shopkart` → Public → Create
3. "uploading an existing file" click karo
4. Ye saari files drag & drop karo (folder structure maintain karo)
5. Commit changes

---

## STEP 2: Vercel pe deploy karo (Real URL — FREE)

1. vercel.com → Sign up with GitHub
2. "New Project" → shopkart repo select karo
3. Framework: Create React App
4. Deploy button dabao
5. ✅ Tujhe milega: `https://shopkart-xxx.vercel.app`

---

## STEP 3: Firebase setup (Real Login + Database)

1. firebase.google.com → Console → Add Project → "shopkart"
2. **Authentication:**
   - Authentication → Get Started
   - Email/Password → Enable → Save
3. **Firestore Database:**
   - Firestore Database → Create Database
   - Start in test mode → Next → Enable
4. **Storage:**
   - Storage → Get Started → Next → Done
5. **Get Keys:**
   - Project Settings (gear icon) → General
   - "Your apps" → Add App → Web (</>)
   - App nickname: shopkart → Register
   - Copy the firebaseConfig object

6. **Paste keys in `src/firebase.js`:**
```js
const firebaseConfig = {
  apiKey: "AIzaSy...",           // ← paste here
  authDomain: "shopkart.firebaseapp.com",
  projectId: "shopkart-xxxxx",
  storageBucket: "shopkart.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};
```

7. Firebase mein Firestore Rules update karo:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth.uid == userId;
    }
    match /sellers/{sellerId} {
      allow read, write: if request.auth.uid == sellerId;
    }
    match /products/{productId} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    match /orders/{orderId} {
      allow read, write: if request.auth != null;
    }
  }
}
```

---

## STEP 4: Razorpay connect karo

1. Razorpay Dashboard → Settings → API Keys → Generate Key
2. `src/App.jsx` mein search karo: `YOUR_RAZORPAY_KEY_ID`
3. Apna Key ID paste karo

---

## STEP 5: Domain connect karo (Optional)

1. Vercel Dashboard → Project → Settings → Domains
2. Apna domain type karo (e.g., shopkart.in)
3. DNS settings mein Vercel ke nameservers add karo
4. ✅ Live!

---

## Final checklist:
- [ ] GitHub pe code upload
- [ ] Vercel pe deploy (real URL)
- [ ] Firebase project create
- [ ] Firebase keys `firebase.js` mein paste
- [ ] Razorpay Key ID App.jsx mein paste
- [ ] Domain connect (optional)

**Support:** Claude se poocho — main hamesha help karunga! 🚀
